import axios from 'axios'
import React from 'react'
import "./Folder.css"
const Folder = ({el}) => {


  return (
    <div>
        <div>
           <input type="checkbox" />
           <span className='span'>{el.title}</span>
        </div>
        {el.student.map((ele)=>(
          <div>
          <input type="checkbox" defaultChecked={ele.isChecked}/>
          <span>{ele.title1}</span>
          </div>
        ))}
    </div>
  )
}

export default Folder