import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import axios from 'axios';
import Folder from "./components/Folder"

function App() {
  const [data,setData] = useState([])

  let getData = () =>{
    axios.get(`http://localhost:8080/lists`)
    .then((res)=>setData(res.data))
    .catch((err)=>console.log(err))
  }

  useEffect(()=>{
    getData()
  },[])

  console.log(data)
  return (
    <div className="App">
      {data.map((el)=>(
      <Folder el={el}/>
      ))}
    </div>
  );
}

export default App;
