{
   var data= [
      {
        title: "Teacher1",
        isChecked: false,
        student: [
          { 
            title1: "student1",
            isCheck: false
          }, 
          {
            title1: "student2",
            isCheck: false
          }, 
          {
            title1: "student3",
            isCheck: false
          }, 
          {
            title1: "student4",
            isCheck: false
          }
        ]
      },
      {
        title: "Teacher2",
        isChecked: false,
        student: [
          { 
            title1: "student1",
            isCheck: false
          }, 
          {
            title1: "student2",
            isCheck: false
          }, 
          {
            title1: "student3",
            isCheck: false
          }, 
          {
            title1: "student4",
            isCheck: false
          }
        ]
      },
      {
        title: "Teacher3",
        isChecked: false,
        student: [
          { 
            title1: "student1",
            isCheck: false
          }, 
          {
            title1: "student2",
            isCheck: false
          }, 
          {
            title1: "student3",
            isCheck: false
          }, 
          {
            title1: "student4",
            isCheck: false
          }
        ]
      },
      {
        title: "Teacher4",
        isChecked: false,
        student: [
          { 
            title1: "student1",
            isCheck: false
          }, 
          {
            title1: "student2",
            isCheck: false
          }, 
          {
            title1: "student3",
            isCheck: false
          }, 
          {
            title1: "student4",
            isCheck: false
          }
        ]
      },
    ]
  }

  export default data
  